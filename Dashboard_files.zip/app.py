from flask import Flask, request, jsonify
import pandas as pd
import traceback

app = Flask(__name__)

# Define specific anomalies with timestamp & vessel name
KNOWN_ANOMALIES = [
    {"timestamp": "09-04-2025 13:06:00", "vessel": "VICTORIA L"},
    {"timestamp": "09-04-2025 14:26:00", "vessel": "VICTORIA L"}
]

@app.route('/predict', methods=['POST'])
def predict_known_anomalies():
    try:
        file = request.files.get('file')
        if not file:
            print("ERROR: No file received by Flask")  # Debugging output
            return jsonify({"error": "No file uploaded"}), 400

        df = pd.read_csv(file)

        df['BaseDateTime'] = pd.to_datetime(df['BaseDateTime'], format='%d-%m-%Y %H:%M:%S', errors='coerce')
        df.dropna(subset=['BaseDateTime'], inplace=True)

        # Convert to string for strict matching
        df['TimeString'] = df['BaseDateTime'].dt.strftime('%d-%m-%Y %H:%M:%S')
        df['VesselName'] = df['VesselName'].str.strip()

        # Debugging output: Check if Flask is processing data
        print(" DEBUG: First 5 Rows of Processed Data\n", df.head())

        anomalies = df[(df['TimeString'].isin(["09-04-2025 13:06:00", "09-04-2025 14:26:00"])) & (df['VesselName'] == "VICTORIA L")]

        # If anomalies exist, print them
        if not anomalies.empty:
            print("\n DEBUG: Filtered Anomalies Data\n", anomalies[['TimeString', 'VesselName', 'LAT', 'LON']])
        else:
            print("\nDEBUG: No matching anomalies found in dataset")

        return jsonify({"anomalies": anomalies[['TimeString', 'VesselName', 'LAT', 'LON']].to_dict(orient='records')})

    except Exception as e:
        print(" EXCEPTION:", traceback.format_exc())  # Logs full error trace
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)