# app.py (Flask backend)
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import cv2
import numpy as np
from shapely.geometry import Polygon
from pyproj import Geod
from decimal import Decimal, getcontext
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)  # Allow frontend to call backend
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

getcontext().prec = 10

def detect_oil_spills(image_path, output_path):
    lat0, lon0 = 30.0000, 70.0000
    meters_per_pixel = 0.1
    lat_deg_per_m = 1 / 111320
    lon_deg_per_m = 1 / (111320 * np.cos(np.radians(lat0)))
    geod = Geod(ellps="WGS84")

    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(f"Image not found: {image_path}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blurred, 50, 255, cv2.THRESH_BINARY_INV)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    output_image = image.copy()
    total_area = Decimal(0)

    for contour in contours:
        if cv2.contourArea(contour) > 500:
            cv2.drawContours(output_image, [contour], -1, (0, 0, 255), 2)
            latlon_coords = []
            for pt in contour[:, 0, :]:
                x, y = pt
                lat = lat0 - (y * meters_per_pixel * lat_deg_per_m)
                lon = lon0 + (x * meters_per_pixel * lon_deg_per_m)
                latlon_coords.append((lon, lat))
            polygon = Polygon(latlon_coords)
            area, _ = geod.geometry_area_perimeter(polygon)
            area_m2 = Decimal(abs(area))
            total_area += area_m2

    cv2.imwrite(output_path, output_image)
    return str(total_area), output_path

@app.route('/detect', methods=['POST'])
def detect():
    if 'image' not in request.files:
        return jsonify({'error': 'No image file uploaded'}), 400
    file = request.files['image']
    filename = secure_filename(file.filename)
    input_path = os.path.join(UPLOAD_FOLDER, filename)
    output_path = os.path.join(RESULT_FOLDER, f"processed_{filename}")
    file.save(input_path)

    try:
        area, processed_path = detect_oil_spills(input_path, output_path)
        return jsonify({
            'area': area,
            'processedImage': processed_path
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/results/<filename>')
def serve_result_image(filename):
    return send_file(os.path.join(RESULT_FOLDER, filename), mimetype='image/jpeg')

if __name__ == '__main__':
    app.run(debug=True)
