import cv2
import numpy as np
import pandas as pd
import joblib
import os
from skimage.feature import graycomatrix, graycoprops
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# ---------- Feature Extraction from Image Array ----------
def extract_features_from_array(image):
    try:
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        mean_intensity = np.mean(gray_image)
        median_intensity = np.median(gray_image)
        std_intensity = np.std(gray_image)
        min_intensity = np.min(gray_image)
        max_intensity = np.max(gray_image)
        intensity_range = max_intensity - min_intensity

        r, g, b = cv2.split(image)
        mean_r, mean_g, mean_b = np.mean(r), np.mean(g), np.mean(b)
        std_r, std_g, std_b = np.std(r), np.std(g), np.std(b)

        glcm = graycomatrix(gray_image, [1, 2, 3], [0, np.pi/4, np.pi/2, 3*np.pi/4],
                            symmetric=True, normed=True)
        texture_features = []
        properties = ['contrast', 'dissimilarity', 'homogeneity', 'energy', 'correlation', 'ASM']
        for prop in properties:
            glcm_property = graycoprops(glcm, prop)
            texture_features.extend(glcm_property.flatten()[:8])

        hist = cv2.calcHist([gray_image], [0], None, [75], [0, 256]).flatten()
        hist_features = hist / np.sum(hist)

        edges = cv2.Canny(gray_image, 100, 200)
        contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        shape_features = [len(contours), np.mean([cv2.contourArea(cnt) for cnt in contours]) if contours else 0]

        if contours:
            largest_contour = max(contours, key=cv2.contourArea)
            perimeter = cv2.arcLength(largest_contour, True)
            area = cv2.contourArea(largest_contour)
            shape_features.extend([perimeter, area])

            if len(largest_contour) >= 5:
                (x, y), (MA, ma), angle = cv2.fitEllipse(largest_contour)
                shape_features.extend([MA, ma, angle])

        while len(shape_features) < 15:
            shape_features.append(0)

        features = [
            mean_intensity, median_intensity, std_intensity, min_intensity,
            max_intensity, intensity_range, mean_r, mean_g, mean_b,
            std_r, std_g, std_b
        ] + texture_features + list(hist_features) + shape_features

        if len(features) != 150:
            raise ValueError(f"Expected 150 features, but got {len(features)}")

        return features
    except Exception as e:
        print(f"Feature extraction failed: {e}")
        return None

# ---------- Model + Scaler ----------
def load_model(model_path):
    return joblib.load(model_path)

def load_scaler(scaler_path):
    return joblib.load(scaler_path)

def predict_oil_spill(model, scaler, features):
    features_array = np.array(features).reshape(1, -1)
    features_scaled = scaler.transform(features_array)
    prediction = model.predict(features_scaled)
    return prediction[0]

# ---------- Divide Image into 25 Regions ----------
def divide_into_25_regions(image):
    h, w = image.shape[:2]
    h_step = h // 5
    w_step = w // 5
    regions = []

    for i in range(5):
        for j in range(5):
            y_start = i * h_step
            y_end = (i + 1) * h_step if i < 4 else h
            x_start = j * w_step
            x_end = (j + 1) * w_step if j < 4 else w
            region = image[y_start:y_end, x_start:x_end]
            regions.append(region)

    return regions

# ---------- Scan Each Image for Spill ----------
def scan_image_for_oil_spill(image_path, model, scaler):
    image = cv2.imread(image_path)
    if image is None:
        print(f"Image not found at {image_path}")
        return 0  # No prediction

    # Scan full image
    features = extract_features_from_array(image)
    if features:
        prediction = predict_oil_spill(model, scaler, features)
        if prediction == 1:
            return 1  # Spill detected in full image

    # Scan all 25 regions
    regions = divide_into_25_regions(image)
    for region in regions:
        features = extract_features_from_array(region)
        if features:
            prediction = predict_oil_spill(model, scaler, features)
            if prediction == 1:
                return 1  # Spill detected in one of the regions

    return 0  # No spill detected in image or any region

# ---------- Evaluation Pipeline ----------
def evaluate_model(test_data_paths, true_labels, model_path, scaler_path):
    model = load_model(model_path)
    scaler = load_scaler(scaler_path)

    predictions = []

    for i, image_path in enumerate(test_data_paths):
        print(f"\nEvaluating image {i+1}/{len(test_data_paths)}: {image_path}")
        prediction = scan_image_for_oil_spill(image_path, model, scaler)
        predictions.append(prediction)

    # Metrics
    accuracy = accuracy_score(true_labels, predictions)
    precision = precision_score(true_labels, predictions, zero_division=0)
    recall = recall_score(true_labels, predictions, zero_division=0)
    f1 = f1_score(true_labels, predictions, zero_division=0)

    print("\n--- Enhanced Model Evaluation (Region-Based) ---")
    print(f"Accuracy : {accuracy:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall   : {recall:.4f}")
    print(f"F1 Score : {f1:.4f}")

# ---------- Run Evaluation ----------
if __name__ == "__main__":
    test_data_paths = ["/content/__results___35_5.png","/content/__results___13_0.png","/content/__results___35_13.png","/content/__results___13_1.png","/content/img_0003.jpg","/content/__results___13_2.png","/content/img_0004.jpg","/content/__results___13_3.png","/content/img_0007.jpg","/content/__results___13_4.png",
                       "/content/img_0008.jpg","/content/__results___35_1.png","/content/img_0010.jpg","/content/__results___35_3.png","/content/img_0011.jpg","/content/__results___35_7.png","/content/img_0012.jpg","/content/__results___35_9.png","/content/img_0013.jpg","/content/__results___35_11.png",
                       "/content/img_0014.jpg","/content/__results___35_19.png","/content/img_0015.jpg","/content/img_0005.jpg","/content/img_0017.jpg","/content/img_0006.jpg","/content/img_0019.jpg","/content/img_0009.jpg","/content/img_0021.jpg","/content/img_0016.jpg",
                       "/content/img_0023.jpg","/content/img_0018.jpg","/content/img_0025.jpg","/content/img_0020.jpg","/content/img_0027.jpg","/content/img_0022.jpg","/content/img_0028.jpg","/content/img_0024.jpg","/content/img_0030.jpg","/content/img_0026.jpg",
                       "/content/img_0031.jpg","/content/img_0029.jpg","/content/img_0032.jpg","/content/img_0042.jpg","/content/img_0033.jpg","/content/img_0047.jpg","/content/img_0034.jpg","/content/img_0048.jpg","/content/img_0035.jpg","/content/img_0050.jpg",
                       "/content/img_0036.jpg","/content/img_0051.jpg","/content/img_0037.jpg","/content/img_0063.jpg","/content/img_0038.jpg","/content/img_0064.jpg","/content/img_0039.jpg","/content/img_0068.jpg","/content/img_0040.jpg","/content/img_0084.jpg",
                       "/content/img_0041.jpg","/content/img_0086.jpg","/content/img_0043.jpg","/content/img_0091.jpg","/content/img_0044.jpg","/content/img_0096.jpg","/content/img_0045.jpg","/content/img_0098.jpg","/content/img_0046.jpg","/content/img_0104.jpg",
                       "/content/img_0049.jpg","/content/img_0106.jpg","/content/img_0051.jpg","/content/img_0109.jpg","/content/img_0052.jpg","/content/img_0110.jpg","/content/img_0053.jpg","/content/internal_waves.png","/content/img_0054.jpg","/content/nos1.jpeg",
                       "/content/img_0055.jpg","/content/nos2.png","/content/img_0056.jpg","/content/nos3.tif","/content/img_0057.jpg","/content/nos4.jpg","/content/img_0058.jpg","/content/nos5.jpg","/content/img_0059.jpg","/content/nos6.jpg",
                       "/content/img_0060.jpg","/content/nos7.jpg","/content/img_0061.jpg","/content/nos8.jpg","/content/img_0062.jpg","/content/nos9.jpg","/content/img_0065.jpg","/content/nos10.jpg","/content/img_0066.jpg","/content/nos11.jpg"]  
    true_labels = [1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
                   1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
                   1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
                   1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,
                   1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0]   
    model_path = '/content/Random_Forest.pkl'
    scaler_path = '/content/scaler.pkl'

    evaluate_model(test_data_paths, true_labels, model_path, scaler_path)