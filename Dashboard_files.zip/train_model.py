import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import joblib

# Load dataset
df = pd.read_csv("NEWCAseStudyData1.csv")

# Convert time to timestamp (in seconds)
df['BaseDateTime'] = pd.to_datetime(df['BaseDateTime'], errors='coerce')
df.dropna(subset=['BaseDateTime', 'LAT', 'LON'], inplace=True)
df['Timestamp'] = df['BaseDateTime'].astype('int64') // 10**9

# Select features
features = df[['LAT', 'LON', 'Timestamp']]

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(features)

# Train Isolation Forest
model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
model.fit(X_scaled)

# Save model and scaler
joblib.dump(model, 'model.pkl')
joblib.dump(scaler, 'scaler.pkl')

print(" Model and scaler saved successfully!")